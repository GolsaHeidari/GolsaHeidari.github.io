
- <strong>The Best Practitioner Paper Award</strong>

Issued by The 25th International Conference on Theory and Practice of Digital Libraries, TPDL'21 · Sep 2021


Associated with Leibniz Universität Hannover

I appreciate Sören Auer and Markus Stocker for their guidance and supervision.


- <strong>Best Lecturer</strong>

Associated with Shahinshahr Azad University


- <strong>Best Lecturer</strong>

Associated with Bonian Higher Education Institute


- <strong>The Best Paper award</strong>
Issued by The International Conference on Security-Enriched Urban Computing and Smart Grid, SUComS 2010, Korea


- <strong>First Rank Among The Graduates of Master’s Degree in Computer Engineering</strong>

Associated with Najafabad Azad University


- <strong>Top 10 Rank in the Master's Global Entrance Exam</strong>

